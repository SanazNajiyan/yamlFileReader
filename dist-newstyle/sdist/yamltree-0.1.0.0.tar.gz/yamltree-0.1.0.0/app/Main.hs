{-# LANGUAGE DeriveGeneric #-}--to derive Generic instances


module Main where
import qualified Data.List as L
import Data.List (isPrefixOf)
import qualified Test.QuickCheck as Q
import Test.QuickCheck (Arbitrary(..), Gen, suchThat)
import Test.QuickCheck (Arbitrary, arbitrary, elements)
import Control.Applicative
import qualified Data.Char as C
import qualified Data.Yaml as Y
import qualified Data.Yaml.Parser as Y
import qualified Data.Yaml.Builder as YB
import Data.Aeson.Types (FromJSON(..), Value(..), withObject, parseJSON)
import qualified Data.Yaml as Y (encode, decode)
import Data.Yaml (FromJSON, parseJSON, ToJSON, ParseException)
import qualified Data.Yaml.Parser as Y
import Text.Libyaml as YL
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import qualified Data.Text.Encoding.Error as TE
import Data.String (IsString(..))
import Data.Maybe
import qualified Data.ByteString.Char8 as BS
import qualified Data.ByteString.Lazy.Char8 as LBS
import qualified Data.ByteString.Lazy as BSL
import qualified Data.Yaml.Pretty as PP
import GHC.Generics
import qualified Data.Map.Strict as Map
import qualified Data.Map as Map

--We (recursively) call a YamlTree regular if all of its (proper) subtrees have the same depth and are regular themselves. Please implement a QuickCheck test that checks whether a YamlTree is regular.


data YamlTree = YamlTree [(String, YamlTree)]
    deriving (Eq, Show, Generic)
--parse function reads the YAML file using the readYamlFile function from the yaml package and returns a Y.YamlValue representing the parsed YAML content
parse :: FilePath -> IO Y.YamlValue
parse path = do
  content <- BS.readFile path
  if BS.null content
    then return (Y.Mapping [] Nothing)
    else Y.readYamlFile path

-- parse :: FilePath -> IO Y.YamlValue
-- parse = Y.readYamlFile 


convertToYAMLTree :: Y.YamlValue -> YamlTree
convertToYAMLTree (Y.Mapping list _) = YamlTree (L.map (\(xs,ys) -> (T.unpack xs, convertToYAMLTree ys)) list)
convertToYAMLTree (Y.Scalar xs _ _ _) = YamlTree [(BS.unpack xs, YamlTree [])] --when we reach a Leaf
--convertToYAMLTree (Y.Sequence list _) = YamlTree $ L.map (\x -> ("-", convertToYAMLTree x)) $ V.toList $ V.fromList list --In this implementation the list argument is first converted to a Vector using V.fromList, and then V.toList is used to convert the Vector to a list.
convertToYAMLTree _ = YamlTree []

yamlTreeToYamlFile :: FilePath -> YamlTree -> IO ()
yamlTreeToYamlFile filePath tree = do
    let yamlText = yamlTreeToText tree
    writeFile filePath yamlText


indent :: Int -> String -> String
indent n line
  | null line = ""
  | otherwise = replicate n ' ' ++ line ++ "\n"
yamlTreeToTextIndented :: Int -> YamlTree -> String
yamlTreeToTextIndented _ (YamlTree []) = ""
yamlTreeToTextIndented indentLevel (YamlTree ((key, value):rest)) =
    subtreeText ++ yamlTreeToTextIndented indentLevel (YamlTree rest)
    where
        subtreeText = indent (indentLevel * 2) key' ++ indentedSubtreeText
        key' = if isStringWithSpaces key then "" else if null valueText then key else key ++ ":"
        indentedSubtreeText = if null valueText then "" else valueText
        valueText = if isStringWithSpaces key
                        then  L.intercalate "" $ map (indent $ (indentLevel + 1) * 2) (words key)
                        else yamlTreeToTextIndented (indentLevel + 1) value 

isStringWithSpaces :: String -> Bool
isStringWithSpaces s = ' ' `elem` s
--pretty printer for YamlTrees that generates a .yaml-file again from your hierarchy  
yamlTreeToText :: YamlTree -> String
yamlTreeToText (YamlTree []) = ""
yamlTreeToText (YamlTree ((key, value):rest)) =
    subtreeText ++ yamlTreeToText (YamlTree rest)
    where
        subtreeText = indent 0 (key ++ ":") ++ indentedSubtreeText
        indentedSubtreeText = yamlTreeToTextIndented 1 value
---------q3-----
--If we pretty print a YAML tree, we should be able to parse it and get the same tree back.
--taking a generated YamlTree and check if it can be parsed back into the same tree
--The property checks whether parsing a YamlTree into a YamlValue and then pretty-printing it back into a YamlTree results in the same YamlTree
--The prop_parser_prettyprinter function takes a YamlTree as input, converts it to text using yamlTreeToText, and then parses the text using parseYaml. If the parse is successful and the resulting tree is equal to the original input tree, the function returns True. Otherwise, it returns False.
prop_parser_prettyprinter :: YamlTree -> Bool
prop_parser_prettyprinter tree = case parseYaml (yamlTreeToText tree) of
  Left err -> error $ "Error: "
  Right t -> if t == tree
             then True
             else error $ "Error: parsed tree is different from original tree.\nOriginal tree:\n" ++ show tree ++ "\nParsed tree:\n" ++ show t ++ "\nYAML string:\n" ++ yamlTreeToText tree 
-- prop_parser_prettyprinter tree = case parseYaml (yamlTreeToText tree) of
-- Left _ -> False
-- Right t -> t == tree
--The parseYaml function takes a String as input, decodes it using Y.decodeEither', and then converts the resulting Value to a YamlTree using convertToYAMLTree. If there is an error during decoding, the function returns a Left containing the error message.
parseYaml :: String -> Either Y.ParseException YamlTree
parseYaml input
  | null input = Right $ YamlTree []
  | otherwise =
    case Y.decodeEither' (BS.pack input) of
      Left err -> Left err
      Right v -> Right $ convertToYAMLTree v

-- parseYaml :: String -> Either Y.ParseException YamlTree
-- parseYaml input = case Y.decodeEither' (BS.pack input) of
--     Left err -> Left err
--     Right v -> Right $ convertToYAMLTree v 
--The instance FromJSON Y.YamlValue is defined simply as parseJSON = parseJSON, which means that it will use the default implementation of parseJSON provided by FromJSON. Since YamlValue is already an instance of FromJSON, this is sufficient to define the instance.
instance FromJSON Y.YamlValue where
    parseJSON = parseJSON
instance Q.Arbitrary YamlTree where
  arbitrary = do
    keyVals <- Q.listOf1 $ arbitraryKV 40
    return $ YamlTree keyVals
-- The arbitraryYamlTree function generates a YamlTree by randomly choosing between generating a list of key-value pairs or an empty list.
--The arbitrary instance for YamlTree generates a list of key-value pairs using the listOf1 function from QuickCheck. Each key-value pair is generated by the arbitraryKV generator, which generates a non-empty string as the key and a YamlTree as the value. Finally, the arbitraryYamlTree generator generates a YamlTree using the YamlTree constructor and a list of key-value pairs generated by the listOf1 function.    
arbitraryYamlTree :: Int -> Q.Gen YamlTree
arbitraryYamlTree maxDepth = do
    let kvGen = arbitraryKV (maxDepth - 1)
    Q.oneof
        [ YamlTree <$> Q.listOf1 kvGen
        , return $ YamlTree []
        ]
--updated version arbitraryKV generates constant string as the key and a random YamlTree
--This implementation of arbitraryKV always generates a key "ExampleKey" with a random value, and the updated implementation of arbitraryYamlTree generates either a non-empty list of key-value pairs or an empty list
--most updated version with good generation of key-val pairs and termination condition
--arbitraryYamlTree takes a maxDepth argument and uses it to limit the recursion depth. It generates either a non-empty list of key-value pairs or an empty list, depending on the Q.oneof choice. arbitraryKV also takes a maxDepth argument and generates a random key from a list of examples, along with a randomly generated YAML tree
-- The arbitraryKV function generates a single key-value pair by generating a non-empty string as the key and a random YamlTree as the value.
arbitraryKV :: Int -> Q.Gen (String, YamlTree)
-- arbitraryKV 0 = YamlTree ("",YamlTree [])
arbitraryKV maxDepth = do
    key <- Q.elements ["ExampleKey1", "ExampleKey2", "ExampleKey3"]
    val <- arbitraryYamlTree maxDepth
    return (key, val)
-- genYamlTree :: Gen YamlTree
-- genYamlTree = YamlTree [("",YamlTree [])]    
-------------------------------end of last worked-----------    

instance Arbitrary Y.YamlValue where
    arbitrary = Q.oneof [arbitraryMapping, arbitraryScalar]
    
arbitraryMapping :: Gen Y.YamlValue
arbitraryMapping = Y.Mapping <$> arbitraryKeyVals <*> pure Nothing
    where 
        arbitraryKeyVals = Q.listOf1 arbitraryKV
        arbitraryKV = (,) <$> arbitraryText <*> arbitrary
arbitraryScalar :: Q.Gen Y.YamlValue
arbitraryScalar = Y.Scalar 
    <$> arbitraryByteString 
    <*> arbitraryTag 
    <*> arbitraryStyle 
    <*> pure Nothing
    where
        arbitraryByteString = TE.encodeUtf8 . T.pack <$> Q.listOf1 arbitraryChar
        arbitraryTag = pure YL.StrTag -- only generate string tags for simplicity
        arbitraryStyle = Q.elements [YL.Plain, YL.SingleQuoted, YL.DoubleQuoted, YL.Literal]
        arbitraryChar = Q.elements ['a'..'z']
arbitraryText :: Q.Gen T.Text
arbitraryText = T.pack <$> Q.listOf1 arbitraryChar

arbitraryChar :: Q.Gen Char
arbitraryChar = Q.elements (['a'..'z'] ++ ['A'..'Z'] ++ ['0'..'9'])

instance Q.Arbitrary YL.Style where
    arbitrary = Q.elements [YL.Plain, YL.SingleQuoted, YL.DoubleQuoted, YL.Literal]        
main :: IO ()
main = do
    -- yamlValue <- parse "test.yaml"
    --let yamlTree = convertToYAMLTree yamlValue
    Q.quickCheck $ prop_parser_prettyprinter
    -- print yamlValue
    -- let yamlTree = convertToYAMLTree yamlValue
    -- print yamlTree
    -- yamlTreeToYamlFile "output.yaml" yamlTree
    --print $ yamlTreeToText (YamlTree [("", YamlTree[])])
    -- print $ prop_parser_prettyprinter (YamlTree [("", YamlTree [])])
    -- print $ prop_parser_prettyprinter (YamlTree [("key", YamlTree [])])

    -- print yamlTree
    -- --let tree = YamlTree [("bonds",YamlTree [("long-bonds",YamlTree [("us-long-bonds",YamlTree [("US10 US20 US30",YamlTree [])]),("KR10",YamlTree [("KR10",YamlTree [])]),("eu-short-bonds",YamlTree [("OAT BTP",YamlTree [])])]),("short-bonds",YamlTree [("us-short-bonds",YamlTree [("US2 US3 US5",YamlTree [])]),("eu-short-bonds",YamlTree [("SHATZ BTP3",YamlTree [])]),("KR3",YamlTree [("KR3",YamlTree [])])]),("STIRs",YamlTree [("STIRs",YamlTree [("EURIBOR FED",YamlTree [])])])]),("energies",YamlTree [("energies",YamlTree [("oil",YamlTree [("CRUDE_W_mini BRENT-LAST HEATOIL GASOILINE",YamlTree [])]),("gas",YamlTree [("GAS_US_mini GAS-LAST",YamlTree [])])])]),("currencies",YamlTree [("currencies",YamlTree [("usd-fx",YamlTree [("INR-SGX EUR GBP",YamlTree [])]),("eur-fx",YamlTree [("EUR EURGBP",YamlTree [])])])]),("equities",YamlTree [("equities",YamlTree [("us-equities",YamlTree [("SP500_mini R1000",YamlTree [])]),("eu-equities",YamlTree [("AEX DAX",YamlTree [])]),("asia-equities",YamlTree [("KOSPI",YamlTree [])])])]),("vol",YamlTree [("vol",YamlTree [("vol",YamlTree [("VIX V2X VNKI",YamlTree [])])])])]
    -- --print (yamlTreeToTextIndented tree)
    -- yamlTreeToYamlFile "output.yaml" yamlTree
    -- --writeFile "output.yaml" (yamlTreeToTextIndented tree)

--arbitrary so that it never generates "" string. 
--I need to handle empty yaml file . can not be parsed ?
--make a simplist yamlTree with text
--pretty prineter should 
--try to replace the element of the tree to that generator
--arbitrary should parse your specific tree
--then make it general . using generator funciton like listOf

--I need to create an instance of the Arbitrary typeclass for your YamlTree type in order to use it with QuickCheck's quickCheck function. This instance tells QuickCheck how to generate random YamlTree values for testing.
-- instance Arbitrary MyType where
--   arbitrary = do
--     x <- arbitraryChar
--     y <- arbitraryChar
--     return (MyType x y)
    -- To generate a random value of type a, we need a generator for values of that type: Gen a. The default generator for values of any type is arbitrary, which is a method of QuickCheck's Arbitrary type class
    -- Q.quickCheckWith Q.stdArgs { Q.maxSuccess = 100 } prop_parser_prettyprinter
    -- y1 <- Q.generate arbitrary :: IO YamlTree
    -- y2 <- Q.generate arbitrary :: IO YamlTree
    -- putStrLn $ show y1
    -- putStrLn $ show y2    
------depth
-- depth :: YamlTree -> Int
-- depth (YamlTree []) = 1 -- base case, an empty YamlTree has depth 1
-- depth (YamlTree kvs) = 1 + maximum (map (depth . snd) kvs)
--problems: sanaz -> sanaz: in yaml file , 